# **ZassOneMods – ID**

**© 2025 ZassOneMods**  
_All rights reserved._

### ▶︎ Ketentuan
- Dilarang memperjualbelikan atau mengklaim ulang sebagian maupun seluruh kode ini tanpa izin tertulis dari Developer.
- Script ini dapat digunakan, dimodifikasi, dan dibagikan ulang **hanya** untuk tujuan pribadi atau pengembangan.
- Atribusi ke **ZassOneMods** wajib dicantumkan di setiap salinan atau turunan kode.

### ⚠︎ Penafian
Penggunaan script ini sepenuhnya menjadi tanggung jawab pengguna.  
Developer dan kontributor tidak bertanggung jawab atas kerusakan, pelanggaran hukum, atau kerugian yang timbul akibat penggunaan script ini.

### ⚙︎ Sumber Resmi & Pembaruan
[https://www.neolabsofficial.my.id](https://www.neolabsofficial.my.id)  

**Dikembangkan oleh:** `NSLabs Team`